package com.icdatinnovations.uk_primary_school_graduates

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
